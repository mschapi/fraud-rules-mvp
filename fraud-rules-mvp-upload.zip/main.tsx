import React from "react";
import ReactDOM from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";

import { AppLayout } from "./ui/AppLayout";
import { AssistantPage } from "./pages/AssistantPage";
import { RuleBuilderPage } from "./pages/RuleBuilderPage";
import { RuleDetailPage } from "./pages/RuleDetailPage";
import { RulesDashboard } from "./pages/RulesDashboard";
import "./styles.css";

const queryClient = new QueryClient();

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Routes>
          <Route element={<AppLayout />}>
            <Route path="/" element={<Navigate to="/rules" replace />} />
            <Route path="/rules" element={<RulesDashboard />} />
            <Route path="/rules/new" element={<RuleBuilderPage />} />
            <Route path="/rules/:id" element={<RuleDetailPage />} />
            <Route path="/assistant" element={<AssistantPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  </React.StrictMode>,
);

